<?php

require_once "config.php";

include "cabecalho.php";

include_once "funcoes_produtos.php";

$produtos = obterProdutos($pdo);

?>

<h1>Produtos</h1>

<a href="cadastro_produto.php">
    Novo Produto
</a>

<br><br>

<?php

exibirTabelaProdutos($produtos);

?>